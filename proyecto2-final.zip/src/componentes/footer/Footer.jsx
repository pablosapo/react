import './Footer.css';

function Footer(){
    return(
        <footer className='footer'>
                <p>Derechos de autor © 2023 son para Pablo Szczapowy</p>

        </footer>
    )
}

export default Footer;